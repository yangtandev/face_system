from zoneinfo import ZoneInfo
import time,datetime
import requests as req
class API:
    r"""
    用於pvms-api的各種進出紀錄

    :param url: API_url  ※ -->{project}.api.ginibio.com/api/v1
    :param location_ID: 出入口管制的區域ID 查詢:{project}.api.ginibio.com/api/v1/locations/
    :
    """


    def Scan_today_log(self):
        r"""
        查詢現場人員進出狀況

        return: : `input/out Log <json>`
        """
        today = datetime.date.today()
        midnight = datetime.datetime.combine(today, datetime.time())
        timestamp = time.mktime(midnight.timetuple())
        ret=req.get(self.url+self.inoutLog_url,{"format":"json","start":int(timestamp)})
        inoutLog={}
        for dt in ret.json():
            log_enter=log_exit=0
            inoutLog[dt['staff_id']]={"staff_name":dt['staff_name']}
            if(len(dt['enter'])>0):
                if None in dt['enter']:
                    inoutLog[dt['staff_id']]['state']="exit"
                    continue
                log_enter=max(dt['enter'])
            if(len(dt['exit'])>0):
                log_exit=max(dt['exit'])
            if(log_enter==0 and log_exit==0):
                inoutLog[dt['staff_id']]['state']="No Data"
            if(log_enter>log_exit):
                inoutLog[dt['staff_id']]['state']="enter"
            else:
                inoutLog[dt['staff_id']]['state']="exit"
        return inoutLog
    
    def face_recognition_in(self,staff_id):
        r"""
        臉辨刷進

        :param staff_id: api上的人員ID  查詢: -->{project}.api.ginibio.com/api/v1/staffs/

        return: : `status_code<int>`
        """
        data={"staff_id":staff_id,"location":self.location,"direction":"enter","timestamp":int(time.time())}
        ret=req.post(self.url+self.face_recognition_url,json=data,timeout=1000)
        return ret.status_code
    
    def face_recognition_out(self,staff_id):
        r"""
        臉辨刷出

        :param staff_id: api上的人員ID  查詢: -->{project}.api.ginibio.com/api/v1/staffs/

        return: : `status_code<int>`
        """
        data={"staff_id":staff_id,"location":self.location,"direction":"exit","timestamp":int(time.time())}
        ret=req.post(self.url+self.face_recognition_url,json=data,timeout=1000)
        return ret.status_code
    



    def RFID_in(self,staff_id):
        r"""
        RFID刷入

        :param staff_id: api上的人員ID  查詢: -->{project}.api.ginibio.com/api/v1/staffs/

        return: : `status_code<int>`
        """
        data={"staff_id":staff_id,"location":self.location,"direction":"enter","timestamp":int(time.time())}
        ret=req.post(self.url+self.RFID_url,json=data,timeout=1000)
        return ret.status_code
    
    def RFID_out(self,staff_id):
        r"""
        RFID刷出

        :param staff_id: api上的人員ID  查詢: -->{project}.api.ginibio.com/api/v1/staffs/

        return: :class:`status_code<int>`
        """
        data={"staff_id":staff_id,"location":self.location,"direction":"exit","timestamp":int(time.time())}
        ret=req.post(self.url+self.RFID_url,json=data,timeout=1000)
        return ret.status_code
    
    def car_in(self,license,type=None,image_id=None):
        r"""
        車輛刷入

        :param license: 車牌號碼 

        :param type: 可填入rfid表示rfid刷入

        :param image_id: 可填入圖片上傳回傳的id

        return: :`status_code<int>`

        """
        data={"license":license,"type":type,"location":1,"direction":"enter","timestamp":int(time.time()),"car_license_image_log":image_id}
        if(type==None):
            del data['type']
        if(image_id==None):
            del data['car_license_image_log']
        print(data)
        ret=req.post(self.url+self.car_url,json=data,timeout=1000)
        return ret.status_code




if(__name__=="__main__"):
    a=API("https://demosite.api.ginibio.com/api/v1",1)
    a.face_recognition_out("G11")
    time.sleep(2)
    print(a.Scan_today_log())
