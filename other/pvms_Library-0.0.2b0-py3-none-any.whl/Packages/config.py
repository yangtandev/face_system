import requests as req,time,datetime,json
from .accesses import API as accesses
#from alert import API as alert
from .upload import API as upload
class API(accesses,upload):
    def __init__(self,url,locationID):
        
        self.url=url
        self.location=locationID
        self.face_recognition_url="/accesses/recognition_logs/"
        self.RFID_url="/accesses/rfid_logs/"
        self.car_url="/accesses/vehicle_logs/"
        self.clothing_url="/accesses/clothing_logs/"
        self.update_images_car_url="/accesses/car_license_image_logs/"
        