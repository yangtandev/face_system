from zoneinfo import ZoneInfo
import requests as req,time,datetime,json

class API:

    def _Get_all_staff_data(self):
        ret=req.get(self.url+self.staffs_url)
        ret_json=ret.json()
        return ret_json
    def Get_all_staff_data(self):
        data=self._Get_all_staff_data()
        staff_data={}
        staff_id_list=[]
        for _data in data:
            staff_id=_data['staff_id']
            staff_id_list.append(staff_id)
            del _data['id']
            staff_data[staff_id]=_data
        return staff_id_list,staff_data
    
    def put_staff_update(self,staff_id,edit_data):
       ret=req.put(f"{self.url}{self.staffs_url}{staff_id}/",json=edit_data)
       ret_txt=ret.text
       return ret_txt,ret.status_code
        