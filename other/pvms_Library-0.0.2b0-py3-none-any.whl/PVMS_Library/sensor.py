from zoneinfo import ZoneInfo
import time,datetime
import requests as req


class API:

    def update_weather():
        pass
