from zoneinfo import ZoneInfo
import requests as req,time,datetime,json

class API:

    def clothing_alert(self,img_base64,staff_id="9999"):
        r"""
        未著裝告警

        :param img_base64:
        截圖base64碼

        :param staff_id:
        如果有可以填
        
        return: :  `status_code<int>`

        """

        data={"staff_id":staff_id,"image":img_base64,"location":self.location,"status":"Not_Success","timestamp":str(datetime.datetime.now(ZoneInfo('Asia/Taipei')))}
        ret=req.post(self.url+self.clothing_url,data=data,timeout=3000)
        return ret.status_code

    def car_image_push(self,img_base64):
        r"""
        上傳車輛圖片

        :param img_base64:
        截圖base64碼
        
        return: :class:`status_code<int>`
        """
                
        data={"image":img_base64}
        ret=req.post(self.url+self.update_images_car_url,data=data,timeout=3000)
        return {"status_code":ret.status_code,"image_id":json.loads(ret.text)['id']}